/* Canada 2016 route and summary configuration. */
window.TOUR = {
  stops: [
    ["London", 51.47, -0.42, 1, ""],
    ["Ottawa", 45.42, -75.7, 3.2, "RCAF Polaris"],
    ["Toronto", 43.68, -79.62, 3.6, "RCAF Polaris"],
    ["Montréal", 45.47, -73.74, 3.6, "RCAF Polaris"],
    ["Québec City", 46.81, -71.21, 3.6, "VIA Rail"],
    ["Winnipeg", 49.9, -97.14, 2.6, "RCAF Polaris"],
    ["Calgary", 51.05, -114.07, 2.8, "RCAF Polaris"],
    ["Fort McMurray", 56.73, -111.38, 2.8, "RCAF Challenger"],
    ["Banff", 51.18, -115.57, 3.4, "Air to Calgary, then road"],
    ["Whitehorse", 60.72, -135.06, 2.4, "RCAF Challenger"],
    ["Victoria", 48.43, -123.37, 3.8, "RCAF Challenger"],
    ["Vancouver", 49.29, -123.12, 4.4, "Harbour Air seaplane"],
    ["London", 51.47, -0.45, 1, "Air Canada"],
  ],
  overview: {
    rotation: [98, -57],
    zoom: 1.7,
  },
  after: {
    rotation: [100, -55],
    zoom: 1.9,
  },
  outbound: {
    rotation: [40, -50],
    zoom: 1.05,
  },
  home: {
    rotation: [60, -55],
    zoom: 1.05,
  },
  homeVia: [],
  routeLabel: "London → Canada → London",
  arrivalLabels: {},
  stats: [
    {
      value: "miles",
      label: "Miles in all",
    },
    {
      value: "stops",
      label: "Stops",
    },
    {
      value: 5,
      label: "Time zones crossed",
    },
  ],
};
