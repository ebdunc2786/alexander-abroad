/* BALTICS · POLAND · UKRAINE route and summary configuration. */
window.TOUR = {
  coverageWhat: "The coverage",
  coverageLabel: "Coverage",
  stops: [
    ["London", 51.5, -0.42, 1, ""],
    ["Tallinn", 59.44, 24.75, 4.2, "RAF flight"],
    ["Tapa", 59.26, 25.96, 6, "Road"],
    ["Riga", 56.95, 24.11, 4.2, "Official flight"],
    ["Vilnius", 54.69, 25.28, 4.2, "Official flight"],
    ["Warsaw", 52.23, 21.01, 3.6, "Official flight"],
    ["Kyiv & Bucha", 50.45, 30.52, 3.2, "Night train from Przemyśl"],
    ["London", 51.5, -0.42, 1, "Train & official flight"],
  ],
  overview: {
    rotation: [-25, -55],
    zoom: 3.1,
  },
  after: {
    rotation: [-25, -55],
    zoom: 3.1,
  },
  outbound: {
    rotation: [-10, -55],
    zoom: 1.5,
  },
  home: {
    rotation: [-14, -53],
    zoom: 1.4,
  },
  homeVia: [],
  routeLabel: "London → Baltics → Poland → Ukraine → London",
  arrivalLabels: {},
  stats: [
    {
      value: "miles",
      label: "Miles in all",
    },
    {
      value: "stops",
      label: "Stops",
    },
    {
      value: 2,
      label: "Hours ahead of London",
    },
  ],
};
