/* Shared tour runtime: route data is supplied by window.TOUR. */
(() => {
  // stops: name, lat, lon, zoom (globe radius multiplier), mode of arrival
  const tour = window.TOUR;
  const STOPS = tour.stops;
  const LAST = STOPS.length - 1;
  const NS = LAST - 1;
  const AT = (s) => [s[2], s[1]];
  const legMi = (i) => Math.round(d3.geoDistance(AT(STOPS[i - 1]), AT(STOPS[i])) * 3958.8);
  const fmt = (n) => n.toLocaleString("en-GB");
  let total = 0,
    air = 0,
    heli = 0;
  for (let i = 1; i < STOPS.length; i++) {
    const m = legMi(i);
    total += m;
    if (STOPS[i][4] === "Helicopter") heli += m;
    else air += m;
  }
  document.getElementById("totMiles").textContent = fmt(total);
  document.querySelectorAll("[data-leg]").forEach((el) => {
    const i = +el.dataset.leg;
    el.textContent = `${STOPS[i][4]} · ${fmt(legMi(i))} mi`;
  });
  const summaryValues = {
    miles: fmt(total),
    stops: String(NS),
    earthPercent: fmt(Math.round((total / 24901) * 100)) + "%",
  };
  const stats = tour.stats || [
    { value: "miles", label: "Miles in all" },
    { value: "stops", label: "Stops" },
    { value: "earthPercent", label: "Of the way round the Earth" },
  ];
  document.getElementById("ledger").innerHTML = stats
    .map(
      (stat) =>
        "<div><b>" +
        (summaryValues[stat.value] ?? stat.value) +
        "</b><span>" +
        stat.label +
        "</span></div>",
    )
    .join("");

  // Palette: the same CSS variables used by the page.
  let COL = {};
  function readCols() {
    const styles = getComputedStyle(document.body);
    const colour = (name) => {
      let value = styles.getPropertyValue(name).trim();
      while (/^var\(/.test(value)) value = styles.getPropertyValue(value.slice(4, -1)).trim();
      return value;
    };
    COL = {
      brass: colour("--tour-accent"),
      rose: colour("--tour-route"),
      sky: colour("--tour-air-route"),
      ink: colour("--tour-ink"),
      muted: colour("--text-muted"),
      gh: colour("--tour-globe-hi"),
      gl: colour("--tour-globe-lo"),
      land: colour("--tour-land"),
      bg: colour("--tour-paper"),
    };
  }
  readCols();

  // Canvas globe and route drawing.
  const cv = document.getElementById("globe"),
    x = cv.getContext("2d"),
    W = 880,
    C = 440,
    R = 380;
  const proj = d3.geoOrthographic().translate([C, C]).clipAngle(90).precision(0.3);
  const path = d3.geoPath(proj, x);
  const land = topojson.merge(WORLD, WORLD.objects.countries.geometries);
  const borders = topojson.mesh(WORLD, WORLD.objects.countries, (a, b) => a !== b);
  const grat = d3.geoGraticule10();
  let cur = -1,
    rot = [-120, 20],
    tRot = [-120, 20],
    sc = R,
    tSc = R;
  function routeTo(n) {
    return { type: "LineString", coordinates: STOPS.slice(1, Math.max(2, n + 1)).map(AT) };
  }
  const fullRoute = { type: "LineString", coordinates: STOPS.slice(1, LAST).map(AT) };
  function draw() {
    proj.rotate(rot).scale(sc);
    x.clearRect(0, 0, W, W);
    x.save();
    x.beginPath();
    x.arc(C, C, R, 0, 7);
    x.clip();
    const g = x.createRadialGradient(C - 130, C - 150, 30, C, C, R);
    g.addColorStop(0, COL.gh);
    g.addColorStop(1, COL.gl);
    x.fillStyle = g;
    x.fillRect(0, 0, W, W);
    x.globalAlpha = 0.12;
    x.strokeStyle = COL.brass;
    x.lineWidth = 0.8;
    x.beginPath();
    path(grat);
    x.stroke();
    x.globalAlpha = 1;
    x.fillStyle = COL.land;
    x.beginPath();
    path(land);
    x.fill();
    x.globalAlpha = 0.5;
    x.strokeStyle = COL.bg;
    x.lineWidth = 0.8;
    x.beginPath();
    path(borders);
    x.stroke();
    x.globalAlpha = 0.85;
    x.strokeStyle = COL.brass;
    x.lineWidth = 1;
    x.beginPath();
    path(land);
    x.stroke();
    // outbound / home legs
    x.setLineDash([3, 7]);
    x.lineWidth = 1.4;
    x.strokeStyle = COL.sky;
    if (cur >= 0) {
      x.globalAlpha = 0.7;
      x.beginPath();
      path({ type: "LineString", coordinates: [AT(STOPS[0]), AT(STOPS[1])] });
      x.stroke();
    }
    if (cur >= LAST || cur === 99) {
      x.beginPath();
      path({
        type: "LineString",
        coordinates: [
          AT(STOPS[NS]),
          ...(tour.homeVia || []).map((i) => AT(STOPS[i])),
          AT(STOPS[LAST]),
        ],
      });
      x.stroke();
    }
    x.setLineDash([]);
    // route
    x.globalAlpha = 0.25;
    x.strokeStyle = COL.rose;
    x.lineWidth = 1.5;
    x.beginPath();
    path(fullRoute);
    x.stroke();
    const n = cur === 99 ? NS : Math.min(cur, NS);
    if (n >= 1) {
      x.globalAlpha = 1;
      x.lineWidth = 2.4;
      x.beginPath();
      path(routeTo(n));
      x.stroke();
    }
    // stops
    const center = [-rot[0], -rot[1]],
      zoomed = sc > R * 2.2;
    x.font = getComputedStyle(document.body).getPropertyValue("--globe-label-font").trim();
    STOPS.slice(1, LAST).forEach((s, j) => {
      const i = j + 1,
        p = AT(s);
      if (d3.geoDistance(p, center) > Math.PI / 2 - 0.02) return;
      const [a, b] = proj(p);
      const on = i === cur,
        past = i <= n;
      x.globalAlpha = on ? 1 : past ? 0.9 : 0.45;
      x.fillStyle = on ? COL.brass : past ? COL.rose : COL.muted;
      x.beginPath();
      x.arc(a, b, on ? 9 : 5, 0, 7);
      x.fill();
      if (on) {
        x.globalAlpha = 0.5;
        x.strokeStyle = COL.brass;
        x.lineWidth = 1.5;
        x.beginPath();
        x.arc(a, b, 20, 0, 7);
        x.stroke();
      }
      if (zoomed && (on || Math.abs(i - cur) <= 2 || cur === 99)) {
        x.globalAlpha = on ? 1 : 0.7;
        x.fillStyle = COL.ink;
        x.fillText(s[0], a + 14, b + 5);
      }
    });
    x.restore();
    x.globalAlpha = 1;
    x.strokeStyle = COL.brass;
    x.lineWidth = 1.4;
    x.beginPath();
    x.arc(C, C, R, 0, 7);
    x.stroke();
  }
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  function tick() {
    const k = reduce ? 1 : 0.07;
    let dl = tRot[0] - rot[0];
    dl = ((dl + 540) % 360) - 180;
    rot = [rot[0] + dl * k, rot[1] + (tRot[1] - rot[1]) * k, 0];
    sc += (tSc - sc) * k;
    draw();
    requestAnimationFrame(tick);
  }
  function frame(i) {
    if (i === -1) {
      tRot = tour.overview.rotation;
      tSc = R * tour.overview.zoom;
      return;
    }
    if (i === 99) {
      tRot = tour.after.rotation;
      tSc = R * tour.after.zoom;
      return;
    }
    if (i === 0) {
      tRot = tour.outbound.rotation;
      tSc = R * tour.outbound.zoom;
      return;
    }
    if (i === LAST) {
      tRot = tour.home.rotation;
      tSc = R * tour.home.zoom;
      return;
    }
    const s = STOPS[i];
    tRot = [-s[2], -s[1]];
    tSc = R * s[3];
  }

  // Full-page chapter navigation.
  const secs = [...document.querySelectorAll("main [data-stop]")];
  const nW = document.getElementById("nWhen"),
    nWh = document.getElementById("nWhat"),
    nS = document.getElementById("nStat");
  function upTo(i) {
    let m = 0;
    for (let k = 1; k <= Math.min(i, LAST); k++) m += legMi(k);
    return m;
  }
  const rail = document.getElementById("rail");
  const navItems = [
    {
      key: "briefing",
      el: secs.find((s) => s.classList.contains("chap") && s.dataset.stop === "-1"),
      label: "Briefing",
    },
    ...STOPS.slice(1, LAST).map((s, j) => ({
      key: String(j + 1),
      el: secs.find((e) => +e.dataset.stop === j + 1),
      label: tour.arrivalLabels?.[s[0]] || s[0],
    })),
    { key: "home", el: secs.find((s) => +s.dataset.stop === LAST), label: "Home" },
    { key: "online", el: secs.find((s) => s.dataset.what === (tour.coverageWhat || "Online")), label: tour.coverageLabel || "Online" },
    { key: "after", el: secs.at(-1), label: "After" },
  ];
  function shortDate(value) {
    const months = {
      January: "JAN",
      February: "FEB",
      March: "MAR",
      April: "APR",
      May: "MAY",
      June: "JUN",
      July: "JUL",
      August: "AUG",
      September: "SEP",
      October: "OCT",
      November: "NOV",
      December: "DEC",
    };
    return value
      .replace(
        /January|February|March|April|May|June|July|August|September|October|November|December/g,
        (month) => months[month],
      )
      .replace(/\b20\d{2}\b/g, "")
      .trim();
  }
  rail.innerHTML = navItems
    .map(
      (n, i) =>
        '<button type="button" data-nav="' +
        i +
        '" title="' +
        n.label +
        '"><small>' +
        shortDate(n.el.dataset.when || "") +
        "</small><span>" +
        n.label +
        "</span></button>",
    )
    .join("");
  const railBtns = [...rail.querySelectorAll("button")];
  let activeSection = secs[0],
    lastNav = -1;
  function activate(el) {
    if (el === activate.last) return;
    activate.last = el;
    activeSection = el;
    const i = +el.dataset.stop;
    cur = i;
    frame(i);
    nW.textContent = el.dataset.when || "";
    nWh.textContent = el.dataset.what || "";
    nS.textContent =
      i >= 1 && i <= LAST
        ? "Stop " + Math.min(i, NS) + " of " + NS + " · " + fmt(upTo(i)) + " miles so far"
        : i === 0
          ? fmt(legMi(1)) + " miles to the first stop"
          : i === 99
            ? fmt(total) + " miles in all"
            : tour.routeLabel;
    const ni = navItems.findIndex((n) => n.el === el);
    railBtns.forEach((b, j) => {
      const on = j === ni;
      b.classList.toggle("on", on);
      b.classList.toggle("done", ni >= 0 && j < ni);
      b.setAttribute("aria-current", on ? "step" : "false");
    });
    document.getElementById("railStatus").textContent =
      i >= 1 && i <= NS
        ? String(i).padStart(2, "0") + " / " + NS
        : el.dataset.what || "THE JOURNEY";
    if (ni >= 0 && ni !== lastNav) {
      lastNav = ni;
      const b = railBtns[ni];
      if (
        b.offsetLeft < rail.scrollLeft ||
        b.offsetLeft + b.offsetWidth > rail.scrollLeft + rail.clientWidth
      )
        rail.scrollTo({
          left: b.offsetLeft - rail.clientWidth / 2 + b.offsetWidth / 2,
          behavior: reduce ? "instant" : "smooth",
        });
    }
  }
  function chapterOffset() {
    return parseFloat(
      getComputedStyle(document.documentElement).getPropertyValue("--chapter-scroll-offset"),
    );
  }
  function jump(el) {
    const offset = chapterOffset();
    scrollTo({
      top: Math.max(0, scrollY + el.getBoundingClientRect().top - offset),
      behavior: reduce ? "instant" : "smooth",
    });
  }
  railBtns.forEach((b, i) => (b.onclick = () => jump(navItems[i].el)));
  const up = document.getElementById("up"),
    down = document.getElementById("down");
  up.onclick = () => jump(secs[Math.max(0, secs.indexOf(activeSection) - 1)]);
  down.onclick = () => jump(secs[Math.min(secs.length - 1, secs.indexOf(activeSection) + 1)]);
  function update() {
    const offset = chapterOffset();
    const cut =
      offset + (innerHeight - offset - document.querySelector(".bottom").offsetHeight) * 0.28;
    let current = secs[0];
    secs.forEach((s) => {
      if (s.getBoundingClientRect().top <= cut) current = s;
    });
    activate(current);
    up.disabled = scrollY <= 1;
    down.disabled = scrollY >= document.documentElement.scrollHeight - innerHeight - 2;
  }
  function fit() {
    const v = window.visualViewport;
    document.documentElement.style.setProperty(
      "--viewport-lift",
      (v ? Math.max(0, innerHeight - v.height - v.offsetTop) : 0) + "px",
    );
    document.documentElement.style.setProperty(
      "--rail-height",
      document.querySelector(".bottom").getBoundingClientRect().height + "px",
    );
    update();
  }
  addEventListener("scroll", update, { passive: true });
  addEventListener("resize", fit);
  visualViewport?.addEventListener("resize", fit);
  new ResizeObserver(fit).observe(document.querySelector(".bottom"));
  readCols();
  fit();
  rot = [...tRot, 0];
  sc = tSc;
  tick();

  // Re-read CSS colours when a palette is changed while editing.
  new MutationObserver(readCols).observe(document.body, {
    attributes: true,
    attributeFilter: ["data-tour", "style"],
  });
})();
