/* USA 2017 route and summary configuration. */
window.TOUR = {
  stops: [
    ["London", 51.47, -0.45, 1, ""],
    ["Washington", 38.9, -77.04, 2.6, "British Airways"],
    ["New York", 40.77, -73.97, 2.6, "American Airlines shuttle"],
    ["Chicago", 41.88, -87.63, 2.6, "American Airlines"],
    ["Houston", 29.76, -95.37, 2.6, "United"],
    ["Los Angeles", 34.06, -118.3, 2.6, "United"],
    ["Santa Barbara", 34.4, -119.52, 3.4, "Motorcade on the 101"],
    ["London", 51.47, -0.45, 1, "British Airways"],
  ],
  overview: {
    rotation: [97, -38],
    zoom: 1.9,
  },
  after: {
    rotation: [97, -38],
    zoom: 1.9,
  },
  outbound: {
    rotation: [45, -48],
    zoom: 1.05,
  },
  home: {
    rotation: [60, -50],
    zoom: 1,
  },
  homeVia: [],
  routeLabel: "London → United States → London",
  arrivalLabels: {},
  stats: [
    {
      value: "miles",
      label: "Miles in all",
    },
    {
      value: "stops",
      label: "Stops",
    },
    {
      value: 8,
      label: "Hours behind London by the end",
    },
  ],
};
