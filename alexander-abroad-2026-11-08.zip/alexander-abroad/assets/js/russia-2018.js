/* RUSSIA route and summary configuration. */
window.TOUR = {
  stops: [
    ["London", 51.5, -0.42, 1, ""],
    ["Moscow", 55.75, 37.62, 3, "RAF flight"],
    ["St Petersburg", 59.94, 30.31, 3, "Sapsan train"],
    ["Tsarskoe Selo", 59.72, 30.4, 6, "Motorcade"],
    ["Ekaterinburg", 56.84, 60.61, 2.6, "Aeroflot"],
    ["Star City & Moscow", 55.88, 38.11, 3.2, "Aeroflot"],
    ["London", 51.5, -0.42, 1, "RAF flight"],
  ],
  overview: {
    rotation: [-45, -58],
    zoom: 2.4,
  },
  after: {
    rotation: [-45, -58],
    zoom: 2.4,
  },
  outbound: {
    rotation: [-15, -53],
    zoom: 1.4,
  },
  home: {
    rotation: [-20, -54],
    zoom: 1.3,
  },
  homeVia: [],
  routeLabel: "London → Russia → London",
  arrivalLabels: {},
  stats: [
    {
      value: "miles",
      label: "Miles in all",
    },
    {
      value: "stops",
      label: "Stops",
    },
    {
      value: 3,
      label: "Hours ahead of London",
    },
  ],
};
